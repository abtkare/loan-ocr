"""اختبار متانة يدوي على صور حقيقية (لا تُضمَّن في المشروع حفاظًا على الخصوصية).

التشغيل:  python -m tests.robustness front.jpg back.jpg expected.json
"""
import json
import sys
import time

import cv2
import numpy as np

from app.ocr.national_id import merge, read_back, read_front


def tilt(im, a):
    h, w = im.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2, h / 2), a, 1)
    return cv2.warpAffine(im, m, (w, h), borderMode=cv2.BORDER_REPLICATE)


DISTORTIONS = {
    "original": lambda i: i,
    "upside_down": lambda i: cv2.rotate(i, cv2.ROTATE_180),
    "tilt_12deg": lambda i: tilt(i, 12),
    "landscape": lambda i: cv2.rotate(i, cv2.ROTATE_90_CLOCKWISE),
    "dark": lambda i: (i * 0.5).astype(np.uint8),
    "blur": lambda i: cv2.GaussianBlur(i, (7, 7), 0),
    "low_res": lambda i: cv2.resize(i, None, fx=0.5, fy=0.5),
}

if __name__ == "__main__":
    front, back = cv2.imread(sys.argv[1]), cv2.imread(sys.argv[2])
    truth = json.load(open(sys.argv[3], encoding="utf-8"))
    for name, fn in DISTORTIONS.items():
        t = time.time()
        r = merge(read_front(fn(front)), read_back(fn(back)))["fields"]
        bad = {k: (r.get(k) or {}).get("value") for k, v in truth.items() if (r.get(k) or {}).get("value") != v}
        print(f"{name:12s} {time.time() - t:5.1f}s", "OK" if not bad else bad)
