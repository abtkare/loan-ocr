from datetime import date

from app.ocr.mrz import check_digit, parse_mrz_candidates

# شريط اصطناعي بصيغة البطاقة العراقية (بيانات وهمية)
L1 = "IDIRQA12345678" + check_digit("A12345678") + "200012345678<<<"
DOB, EXP = "900115", "310220"
L2 = DOB + check_digit(DOB) + "F" + EXP + check_digit(EXP) + "IRQ<<<<<<<<<<<0"
L3 = "AHMED<<SARA<<<<<<<<<<<<<<<<<<<"


def test_check_digit_known_values():
    # أمثلة الوثيقة النموذجية في معيار ICAO 9303
    assert check_digit("L898902C3") == "6"
    assert check_digit("740812") == "2"
    assert check_digit("120415") == "9"


def test_parses_clean_mrz():
    r = parse_mrz_candidates(["\n".join([L1, L2, L3])])
    assert r.valid
    assert r.document_number == "A12345678"
    assert r.national_id_number == "200012345678"
    assert r.date_of_birth == date(1990, 1, 15)
    assert r.expiry_date == date(2031, 2, 20)
    assert r.sex == "female"
    assert (r.surname_latin, r.given_names_latin) == ("AHMED", "SARA")


def test_recovers_from_common_ocr_mistakes():
    noisy_l2 = L2.replace("0", "O", 2).replace("1", "I", 1)  # أخطاء OCR معتادة
    r = parse_mrz_candidates(["\n".join([L1.replace("1", "I", 1), noisy_l2, L3])])
    assert r.valid
    assert r.date_of_birth == date(1990, 1, 15)


def test_rejects_wrong_check_digits():
    bad = L2[:6] + str((int(L2[6]) + 1) % 10) + L2[7:]
    r = parse_mrz_candidates(["\n".join([L1, bad, L3])])
    assert not r.checks["dates"]
    assert not r.valid


def test_votes_on_latin_name():
    reads = ["\n".join([L1, L2, n]) for n in (L3, L3, "AHNED<<SARA<<<")]
    r = parse_mrz_candidates(reads)
    assert r.surname_latin == "AHMED"
