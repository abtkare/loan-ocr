from datetime import date

from app.ocr.iraq_data import snap_place
from app.ocr.national_id import _family_number, _gender
from app.ocr.text_utils import clean_arabic, digits_only, parse_date


def test_clean_arabic_strips_noise():
    assert clean_arabic(": عبد الحسين :") == "عبد الحسين"
    assert clean_arabic("‏الربيعيـ ©") == "الربيعي"


def test_arabic_digits_and_dates():
    assert digits_only("١٩٨٧ ٠٥") == "198705"
    assert parse_date("1987/05/09") == date(1987, 5, 9)
    assert parse_date("٢٠٢٣/٠٨/٠٩") == date(2023, 8, 9)
    assert parse_date("2023/13/40") is None


def test_place_snapping():
    assert snap_place("النجف-النجفن") == "النجف-النجف"


def test_family_number_format():
    assert _family_number("1247LOOM2890018801") == "1247L00M2890018801"
    assert _family_number("12345") == ""


def test_gender():
    assert _gender("ذكر") == "male"
    assert _gender("أنثى") == "female"
