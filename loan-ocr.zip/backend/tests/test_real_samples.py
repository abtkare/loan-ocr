"""اختبار على صور حقيقية — يعمل فقط إن وضعت الصور في مجلد وحددته بالمتغير SAMPLES_DIR.

المجلد يحتوي: front.jpg و back.jpg و expected.json (القيم الصحيحة).
لا تضع صورًا حقيقية داخل المشروع أو GitHub.
"""
import json
import os

import cv2
import pytest

from app.ocr.national_id import merge, read_back, read_front

DIR = os.getenv("SAMPLES_DIR")


@pytest.mark.skipif(not DIR, reason="SAMPLES_DIR غير محدد")
def test_real_card():
    r = merge(read_front(cv2.imread(os.path.join(DIR, "front.jpg"))),
              read_back(cv2.imread(os.path.join(DIR, "back.jpg"))))
    expected = json.load(open(os.path.join(DIR, "expected.json"), encoding="utf-8"))
    got = {k: r["fields"].get(k, {}).get("value") for k in expected}
    assert got == expected
    assert r["mrz_verified"]
