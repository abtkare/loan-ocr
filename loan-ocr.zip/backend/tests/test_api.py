import cv2
import numpy as np
from starlette.testclient import TestClient

from app.main import app

client = TestClient(app)


def _jpeg(w=800, h=500):
    img = np.full((h, w, 3), 230, np.uint8)
    return cv2.imencode(".jpg", img)[1].tobytes()


def test_health():
    assert client.get("/api/health").json() == {"status": "ok"}


def test_requires_an_image():
    r = client.post("/api/v1/documents/national-id", files={})
    assert r.status_code == 400


def test_rejects_non_image():
    r = client.post("/api/v1/documents/national-id", files={"front": ("x.jpg", b"not an image", "image/jpeg")})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "invalid_image"


def test_blank_image_returns_structure_not_crash():
    r = client.post("/api/v1/documents/national-id", files={"front": ("f.jpg", _jpeg(), "image/jpeg")})
    assert r.status_code == 200
    body = r.json()
    assert body["document_type"] == "iraq_national_id"
    assert body["mrz_verified"] is False
    assert r.headers["cache-control"] == "no-store"
    assert any("حواف" in w for w in body["warnings"])
