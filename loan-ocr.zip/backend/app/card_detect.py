"""كشف البطاقة في الصورة وتعديل منظورها إلى مستطيل قياسي."""
import cv2
import numpy as np

CARD_W, CARD_H = 1712, 1080  # نسبة ID-1 (85.6×54 مم) بدقة عالية


def _order(pts: np.ndarray) -> np.ndarray:
    pts = pts.reshape(4, 2).astype("float32")
    s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
    return np.array([pts[s.argmin()], pts[d.argmin()], pts[s.argmax()], pts[d.argmax()]], dtype="float32")


def find_card_quad(img: np.ndarray):
    """يرجع زوايا البطاقة الأربع أو None إن لم يجدها."""
    h, w = img.shape[:2]
    scale = 800 / max(h, w)
    small = cv2.resize(img, None, fx=scale, fy=scale)
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    area_img = small.shape[0] * small.shape[1]
    candidates = []
    masks = [cv2.dilate(cv2.Canny(gray, 40, 120), np.ones((5, 5), np.uint8))]
    # البطاقة أفتح من الخلفية عادةً: نجرب عدة عتبات إضاءة لنتحمل الإضاءة المتفاوتة
    for t in (120, 140, 160, 180, 200):
        _, th = cv2.threshold(gray, t, 255, cv2.THRESH_BINARY)
        th = cv2.morphologyEx(th, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
        th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, np.ones((25, 25), np.uint8))
        masks.append(th)
    for mask in masks:
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:5]:
            a = cv2.contourArea(c)
            if a < 0.05 * area_img or a > 0.97 * area_img:
                continue
            rect = cv2.minAreaRect(c)
            (rw, rh) = rect[1]
            if min(rw, rh) == 0:
                continue
            ratio = max(rw, rh) / min(rw, rh)
            if not 1.4 < ratio < 1.8:
                continue
            fill = a / (rw * rh)
            if fill < 0.85:
                continue
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            quad = approx if len(approx) == 4 else cv2.boxPoints(rect)
            candidates.append((fill ** 4 * a, quad))
    if not candidates:
        return None
    quad = max(candidates, key=lambda x: x[0])[1]
    return _order(np.asarray(quad) / scale)


def warp_card(img: np.ndarray):
    """يرجع (صورة البطاقة المعدلة، هل وُجدت البطاقة)."""
    quad = find_card_quad(img)
    if quad is None:
        return img, False
    tl, tr, br, bl = quad
    if np.linalg.norm(tr - tl) < np.linalg.norm(bl - tl):  # البطاقة مصورة عموديًا
        quad = np.array([bl, tl, tr, br], dtype="float32")
    dst = np.array([[0, 0], [CARD_W, 0], [CARD_W, CARD_H], [0, CARD_H]], dtype="float32")
    M = cv2.getPerspectiveTransform(quad, dst)
    return cv2.warpPerspective(img, M, (CARD_W, CARD_H), flags=cv2.INTER_CUBIC), True
