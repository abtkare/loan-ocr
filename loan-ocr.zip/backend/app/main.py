"""الخادم: واجهة برمجية لقراءة المستمسكات + تقديم صفحة الويب.

مبادئ الخصوصية المطبقة هنا:
- الصور تُعالج في الذاكرة فقط ولا تُكتب على القرص إطلاقًا.
- لا تُسجَّل محتويات الصور ولا البيانات المستخرجة في السجلات.
- الاستجابة تحمل Cache-Control: no-store حتى لا تخزنها المتصفحات أو الوسطاء.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from collections import defaultdict, deque

import cv2
import numpy as np
from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import config
from .ocr.national_id import merge, read_back, read_front

log = logging.getLogger("loan-ocr")
_ocr_slots = asyncio.Semaphore(config.OCR_WORKERS)
_hits: dict[str, deque] = defaultdict(deque)
MAX_BYTES = int(config.MAX_UPLOAD_MB * 1024 * 1024)


def error(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message}}, status_code=status,
                        headers={"Cache-Control": "no-store"})


def _rate_limited(ip: str) -> bool:
    now = time.monotonic()
    q = _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= config.RATE_LIMIT_PER_MIN:
        return True
    q.append(now)
    return False


async def _read_image(form, name: str):
    """يرجع (الصورة أو None، رسالة خطأ أو None)."""
    upload = form.get(name)
    if upload is None or isinstance(upload, str):
        return None, None
    data = await upload.read(MAX_BYTES + 1)
    await upload.close()
    if len(data) > MAX_BYTES:
        return None, f"حجم الصورة ({name}) أكبر من {config.MAX_UPLOAD_MB:g} ميغابايت."
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    del data
    if img is None:
        return None, f"الملف ({name}) ليس صورة صالحة."
    # تصغير الصور الضخمة: يسرّع القراءة دون خسارة دقة تُذكر
    h, w = img.shape[:2]
    if max(h, w) > 2400:
        s = 2400 / max(h, w)
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    return img, None


async def health(request: Request):
    return JSONResponse({"status": "ok"})


async def national_id(request: Request):
    if config.API_KEY and request.headers.get("x-api-key") != config.API_KEY:
        return error(401, "unauthorized", "مفتاح الوصول غير صحيح.")
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0]
    if _rate_limited(ip):
        return error(429, "rate_limited", "طلبات كثيرة، حاول بعد دقيقة.")
    if int(request.headers.get("content-length") or 0) > 2 * MAX_BYTES + 65536:
        return error(413, "too_large", "حجم الطلب كبير جدًا.")
    try:
        form = await request.form(max_files=2, max_fields=5)
    except Exception:
        return error(400, "bad_request", "تعذر قراءة الطلب. أرسل الصور بصيغة multipart/form-data.")
    front, e1 = await _read_image(form, "front")
    back, e2 = await _read_image(form, "back")
    if e1 or e2:
        return error(400, "invalid_image", e1 or e2)
    if front is None and back is None:
        return error(400, "missing_image", "أرسل صورة الوجه (front) أو الظهر (back) أو كليهما.")

    t0 = time.monotonic()
    async with _ocr_slots:  # طابور: لا نشغل أكثر من OCR_WORKERS قراءة في نفس اللحظة
        f = await run_in_threadpool(read_front, front) if front is not None else None
        b = await run_in_threadpool(read_back, back) if back is not None else None
    result = merge(f, b)
    del front, back
    result["processing_ms"] = int((time.monotonic() - t0) * 1000)
    log.info("national_id processed in %sms (mrz_verified=%s)", result["processing_ms"], result["mrz_verified"])
    return JSONResponse(result, headers={"Cache-Control": "no-store"})


class SecurityHeaders:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        async def _send(message):
            if message["type"] == "http.response.start":
                headers = message.setdefault("headers", [])
                headers += [
                    (b"x-content-type-options", b"nosniff"),
                    (b"referrer-policy", b"no-referrer"),
                    (b"x-frame-options", b"DENY"),
                    (b"permissions-policy", b"camera=(self), microphone=(), geolocation=()"),
                ]
            await send(message)

        await self.app(scope, receive, _send)


def create_app() -> Starlette:
    routes = [
        Route("/api/health", health),
        Route("/api/v1/documents/national-id", national_id, methods=["POST"]),
    ]
    if os.path.isdir(config.FRONTEND_DIR):
        routes.append(Mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True)))
    middleware = [Middleware(SecurityHeaders)]
    if config.CORS_ORIGINS:
        middleware.append(Middleware(CORSMiddleware, allow_origins=config.CORS_ORIGINS,
                                     allow_methods=["POST", "GET"], allow_headers=["X-API-Key"]))
    return Starlette(routes=routes, middleware=middleware)


app = create_app()
