"""قوائم مرجعية تساعد على تصحيح أخطاء OCR الصغيرة بمطابقة تقريبية."""
from difflib import SequenceMatcher

GOVERNORATES = [
    "بغداد", "البصرة", "نينوى", "الموصل", "أربيل", "اربيل", "السليمانية", "دهوك", "كركوك",
    "الأنبار", "الانبار", "ديالى", "صلاح الدين", "بابل", "الحلة", "كربلاء", "النجف",
    "القادسية", "الديوانية", "واسط", "الكوت", "ميسان", "العمارة", "ذي قار", "الناصرية",
    "المثنى", "السماوة", "حلبجة", "الكوفة", "الرمادي", "الفلوجة", "تكريت", "سامراء", "بعقوبة",
]
ISSUERS = [
    "مديرية الجنسية والمعلومات المدنية",
    "مديرية الأحوال المدنية والجوازات والإقامة",
]


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def snap(text: str, choices: list[str], threshold: float = 0.7) -> str | None:
    """يرجع أقرب قيمة معروفة إن كان التشابه كافيًا، وإلا None."""
    if not text:
        return None
    best = max(choices, key=lambda c: similarity(text, c))
    return best if similarity(text, best) >= threshold else None


def snap_place(text: str) -> str:
    """مكان الولادة بصيغة «المحافظة-القضاء»: نصحح كل جزء على حدة إن أمكن."""
    parts = []
    for part in text.split("-"):
        words = [w for w in part.split() if len(w) > 2]
        candidate = " ".join(words)
        # نجرب الكلمات الأخيرة لأن الضجيج يكون غالبًا في طرف القصاصة
        fixed = snap(candidate, GOVERNORATES) or (words and snap(words[-1], GOVERNORATES))
        parts.append(fixed or candidate)
    return "-".join(p for p in parts if p)
