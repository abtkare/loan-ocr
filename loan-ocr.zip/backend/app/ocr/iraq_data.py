"""قوائم مرجعية تساعد على تصحيح أخطاء OCR الصغيرة بمطابقة تقريبية."""
from difflib import SequenceMatcher

GOVERNORATES = [
    "بغداد", "البصرة", "نينوى", "الموصل", "أربيل", "اربيل", "السليمانية", "دهوك", "كركوك",
    "الأنبار", "الانبار", "ديالى", "صلاح الدين", "بابل", "الحلة", "كربلاء", "النجف",
    "القادسية", "الديوانية", "واسط", "الكوت", "ميسان", "العمارة", "ذي قار", "الناصرية",
    "المثنى", "السماوة", "حلبجة", "الكوفة", "الرمادي", "الفلوجة", "تكريت", "سامراء", "بعقوبة",
]
ISSUERS = [
    "مديرية الجنسية والمعلومات المدنية",
    "مديرية الأحوال المدنية والجوازات والإقامة",
]


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def snap(text: str, choices: list[str], threshold: float = 0.7) -> str | None:
    """يرجع أقرب قيمة معروفة إن كان التشابه كافيًا، وإلا None."""
    if not text:
        return None
    best = max(choices, key=lambda c: similarity(text, c))
    return best if similarity(text, best) >= threshold else None


def snap_place(text: str) -> str:
    """مكان الولادة بصيغة «المحافظة-القضاء»: نصحح كل جزء على حدة إن أمكن."""
    parts = []
    for part in text.split("-"):
        words = [w for w in part.split() if len(w) > 2]
        candidate = " ".join(words)
        # نجرب الكلمات الأخيرة لأن الضجيج يكون غالبًا في طرف القصاصة
        fixed = snap(candidate, GOVERNORATES) or (words and snap(words[-1], GOVERNORATES))
        parts.append(fixed or candidate)
    return "-".join(p for p in parts if p)


# أسماء عراقية شائعة لتصحيح خطأ حرف واحد في القراءة (لا تُستبدل الأسماء غير الموجودة هنا)
COMMON_NAMES = """محمد علي حسين حسن احمد أحمد عباس جعفر كاظم جاسم قاسم حيدر مصطفى مرتضى مهدي هادي صادق باقر جواد رضا
كريم عبد زكريا يحيى يوسف ابراهيم إبراهيم اسماعيل إسماعيل موسى عيسى سلمان سليمان داود خليل جليل جميل جمال كمال
فاضل عادل ناصر نصير منصور ستار جبار غفار عبد الله عبدالله الحسين الحسن الامير الأمير الرزاق الكريم الرحمن الرحيم الزهرة
الهادي الرضا الكاظم الجبار الستار الغفار الواحد الحميد المجيد الوهاب العزيز اللطيف الخالق الباقي القادر الصاحب الائمة الأئمة
فلاح صلاح نجاح رياض فراس عمار ياسر سعد سعيد سعدون رعد حمزة طه ياسين نوري صبري خضير خضر لفته عطيه عطية مزهر
فاطمة زينب مريم سكينة رقية زهراء نور هدى عواطف سميرة سعاد خديجة امل أمل ايمان إيمان بشرى حنان وفاء رجاء كوثر نجلاء
الربيعي التميمي الساعدي الكعبي الجبوري الدليمي العبيدي الشمري الزبيدي الخفاجي الموسوي الحسيني الياسري العامري الأسدي الاسدي
الكناني الطائي المالكي البديري الحلفي الغزي السوداني الفتلاوي العكيلي اللامي المحمداوي الدراجي الجنابي الكرخي البغدادي""".split()


def _dist1(a: str, b: str) -> bool:
    """هل الفرق بين الكلمتين حرف واحد على الأكثر (استبدال أو حذف أو إضافة)؟"""
    if abs(len(a) - len(b)) > 1:
        return False
    i = j = d = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1; continue
        d += 1
        if d > 1:
            return False
        if len(a) > len(b): i += 1
        elif len(b) > len(a): j += 1
        else: i += 1; j += 1
    return d + (len(a) - i) + (len(b) - j) <= 1


def fix_name(text: str) -> str:
    out = []
    for w in text.split():
        if len(w) >= 4 and w not in COMMON_NAMES:
            hits = {n for n in COMMON_NAMES if _dist1(w, n)}
            if len(hits) == 1:
                w = hits.pop()
        out.append(w)
    return " ".join(out)
