"""طبقة رقيقة فوق Tesseract: قراءة منطقة من الصورة بعدة نسخ ثم التصويت على النتيجة.

لماذا التصويت؟ صور الهاتف تختلف في الإضاءة والحدة. قراءة المنطقة نفسها بعدة
مقاسات/معالجات ثم اختيار النتيجة الأكثر تكرارًا تقلل الأخطاء العشوائية،
ونسبة الاتفاق بين القراءات تعطينا «درجة ثقة» صادقة لكل حقل.
"""
from __future__ import annotations

from collections import Counter
from typing import Callable

import cv2
import numpy as np
import pytesseract

AR = "ara"
EN = "eng"


def crop(img: np.ndarray, box: tuple[float, float, float, float]) -> np.ndarray:
    """box = (x1, y1, x2, y2) كنسب من عرض وارتفاع البطاقة."""
    h, w = img.shape[:2]
    x1, y1, x2, y2 = box
    return img[max(0, int(y1 * h)):min(h, int(y2 * h)), max(0, int(x1 * w)):min(w, int(x2 * w))]


def _variants(gray: np.ndarray, scales: tuple[float, ...]):
    for s in scales:
        g = cv2.resize(gray, None, fx=s, fy=s, interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
        yield g
        yield cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]


def ocr(gray: np.ndarray, lang: str, psm: int = 7, whitelist: str | None = None) -> str:
    # هامش حول القصاصة: بدونه يخطئ Tesseract في أول حرف (مثلًا 1 تُقرأ 4)
    pad = max(10, gray.shape[0] // 4)
    gray = cv2.copyMakeBorder(gray, pad, pad, pad, pad, cv2.BORDER_REPLICATE)
    cfg = f"--psm {psm}"
    if whitelist:
        cfg += f" -c tessedit_char_whitelist={whitelist}"
    return pytesseract.image_to_string(gray, lang=lang, config=cfg)


def read_field(
    gray: np.ndarray,
    box: tuple[float, float, float, float],
    lang: str,
    clean: Callable[[str], str],
    *,
    whitelist: str | None = None,
    validate: Callable[[str], bool] = bool,
    scales: tuple[float, ...] = (1.0,),
    shifts: tuple[float, ...] = (0.0, -0.008, 0.008),
) -> tuple[str | None, float]:
    """يرجع (القيمة، الثقة من 0 إلى 1)."""
    votes: Counter[str] = Counter()
    total = 0
    x1, y1, x2, y2 = box
    for dy in shifts:
        region = crop(gray, (x1, y1 + dy, x2, y2 + dy))
        for v in _variants(region, scales):
            total += 1
            value = clean(ocr(v, lang, 7, whitelist))
            if value and validate(value):
                votes[value] += 1
    if not votes:
        return None, 0.0
    value, n = votes.most_common(1)[0]
    return value, round(n / total, 2)
