"""استخراج بيانات البطاقة الوطنية العراقية الموحدة (الوجه والظهر).

الاستراتيجية:
1. نعدّل منظور البطاقة إلى مستطيل قياسي، فتصبح أماكن الحقول ثابتة تقريبًا.
2. نقرأ كل حقل من منطقته المعروفة (بالعربية أو الأرقام) مع التصويت.
3. نقرأ شريط MRZ في الظهر ونتحقق منه بأرقام التحقق؛ وعند تعارضه مع
   القراءة العربية نعتمد MRZ لأنه مُتحقق رياضيًا.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import cv2
import numpy as np
import pytesseract

from ..card_detect import warp_card
from . import engine
from .mrz import parse_mrz_candidates
from .anchor import best_offset, find_text_hits, shift_box
from .iraq_data import ISSUERS, fix_name, snap, snap_place
from .text_utils import clean_arabic, digits_only, parse_date

# مواقع الحقول كنسب (x1, y1, x2, y2) من البطاقة بعد تعديل المنظور
FRONT_NAME_ROWS = {
    "first_name": 0.443,
    "father_name": 0.518,
    "grandfather_name": 0.585,
    "surname": 0.660,
    "mother_name": 0.740,
    "mother_grandfather_name": 0.805,
}
FRONT = {
    "national_id_number": (0.30, 0.275, 0.70, 0.36),
    "card_number": (0.00, 0.86, 0.36, 0.98),
    "gender": (0.58, 0.845, 0.765, 0.925),
    "blood_type": (0.53, 0.905, 0.66, 0.985),
}
BACK = {
    "issuer": (0.03, 0.01, 0.62, 0.09),
    "issue_date": (0.03, 0.115, 0.62, 0.195),
    "expiry_date": (0.03, 0.185, 0.62, 0.265),
    "place_of_birth": (0.25, 0.25, 0.598, 0.33),
    "date_of_birth": (0.03, 0.315, 0.62, 0.395),
    "family_number": (0.03, 0.385, 0.62, 0.465),
    "mrz": (0.00, 0.66, 1.00, 0.99),
}
_DATE_WL = "0123456789/"
_ALNUM_WL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
_MRZ_WL = _ALNUM_WL + "<"
# نقاط الارتكاز: (منطقة البحث، النمط، الحروف المسموحة، المكان المتوقع للمركز)
FRONT_ANCHOR = ((0.25, 0.18, 0.75, 0.42), r"\d{10,13}", "0123456789", [(0.511, 0.315)])
# في الظهر ثلاثة تواريخ (الإصدار، النفاذ، الولادة) فنقبل أيًّا منها كمرجع
BACK_ANCHOR = ((0.0, 0.0, 0.7, 0.55), r"\d{4}/\d{2}/\d{2}", "0123456789/",
               [(0.474, 0.150), (0.474, 0.222), (0.474, 0.356)])
BLOOD_TYPES = {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"}


@dataclass
class Field:
    value: object = None
    confidence: float = 0.0
    source: str = "ocr"  # ocr | mrz | mrz+ocr

    def as_dict(self):
        v = self.value.isoformat() if hasattr(self.value, "isoformat") else self.value
        return {"value": v, "confidence": self.confidence, "source": self.source}


def _gray(img: np.ndarray) -> np.ndarray:
    # ملاحظة: جربنا موازنة الإضاءة (CLAHE) فأضعفت قراءة العربية، لذا نكتفي بالرمادي
    # ونترك لعتبة Otsu داخل محرك التصويت معالجة الإضاءة المتفاوتة.
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _mrz_score(gray: np.ndarray) -> int:
    """كم علامة «<» في منطقة الشريط: تكشف اتجاه ظهر البطاقة بثقة."""
    region = cv2.resize(engine.crop(gray, BACK["mrz"]), None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    return engine.ocr(region, engine.EN, 6, _MRZ_WL).count("<")


def _prepare(img: np.ndarray, anchor, back: bool = False):
    """يعدّل المنظور، ويكتشف إن كانت البطاقة مقلوبة، ويحسب إزاحة التصحيح.

    يرجع (الصورة الرمادية، هل وُجدت البطاقة، دالة تزيح أي منطقة بالإزاحة المحسوبة).
    """
    warped, found = warp_card(img)
    box, pattern, wl, expected = anchor
    gray = _gray(warped)
    options = [gray, cv2.rotate(gray, cv2.ROTATE_180)]
    if back:  # في الظهر: الشريط السفلي يحدد الاتجاه، فنضع الاتجاه الأرجح أولًا
        options.sort(key=_mrz_score, reverse=True)
    for g in options:
        hits = find_text_hits(g, box, pattern, wl)
        if hits:
            off = best_offset(hits, expected)
            if off:
                return g, found, lambda b, o=off: shift_box(b, *o)
            return g, found, lambda b: b
    return options[0], found, lambda b: b


_DIG = str.maketrans({"O": "0", "D": "0", "Q": "0", "I": "1", "L": "1", "Z": "2", "S": "5", "B": "8", "G": "6"})
_LET = str.maketrans({"0": "O", "1": "L", "4": "A", "8": "B", "5": "S", "2": "Z"})


def _family_number(text: str) -> str:
    """الرقم العائلي بصيغة: 4 أرقام + حرف + رقمان + حرف + 10 أرقام (مثال 1234L00M1234567890)."""
    t = re.sub(r"[^A-Z0-9]", "", text.upper())
    if len(t) != 18:
        return ""
    t = t[:4].translate(_DIG) + t[4].translate(_LET) + t[5:7].translate(_DIG) + t[7].translate(_LET) + t[8:].translate(_DIG)
    return t if re.fullmatch(r"\d{4}[A-Z]\d{2}[A-Z]\d{10}", t) else ""


def _gender(text: str) -> str:
    t = clean_arabic(text)
    if not t:
        return ""
    if "انث" in t or "أنث" in t or "نثى" in t:
        return "female"
    if "ذك" in t or "كر" in t:
        return "male"
    return ""


# كلمات العناوين (عربية وكردية) التي قد تدخل قصاصة الاسم إن انزاحت الصورة قليلًا
_LABEL_NOISE = {"الاسم", "الأسم", "ناو", "الاب", "الأب", "باوك", "اوك", "وك", "دوك", "الجد", "بابير", "باپير",
                "اللقب", "نازناو", "الام", "الأم", "دايك", "ايك", "الجنس"}


def _clean_name(text: str) -> str:
    toks = [t for t in clean_arabic(text).split() if t not in _LABEL_NOISE]
    # نحذف بقايا الحروف القصيرة في الطرفين (ضجيج الحواف) ما دام في السطر كلمة حقيقية
    while len(toks) > 1 and len(toks[0]) <= 2:
        toks.pop(0)
    while len(toks) > 1 and len(toks[-1]) <= 2:
        toks.pop()
    return fix_name(" ".join(toks))


def _name_bands(g: np.ndarray, at) -> dict:
    """يكتشف أسطر النص في عمود الأسماء فعليًا بدل الاعتماد على مواقع ثابتة.

    يرجع قصاصات الأسطر الستة (الاسم، الأب، الجد، اللقب، الأم، جد الأم) أو قائمة فارغة.
    """
    reg = engine.crop(g, at((0.45, 0.37, 0.755, 0.84)))
    if reg.size == 0:
        return {}
    h = reg.shape[0]
    _, b = cv2.threshold(reg, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    prof = (b > 0).mean(axis=1)
    on = prof > max(0.04, prof.max() * 0.18)
    bands, start = [], None
    for i, v in enumerate(list(on) + [False]):
        if v and start is None:
            start = i
        elif not v and start is not None:
            if i - start >= h * 0.025:
                bands.append([start, i])
            start = None
    merged: list[list[int]] = []
    for bd in bands:  # دمج النقاط والحركات المنفصلة عن سطرها
        if merged and bd[0] - merged[-1][1] < h * 0.015:
            merged[-1][1] = bd[1]
        else:
            merged.append(bd)
    if len(merged) < 3:
        return {}
    # مراكز الأسطر كنسبة من ارتفاع البطاقة، ثم نطابقها مع الأسطر المتوقعة بأفضل إزاحة عامة
    top, bottom = at((0.45, 0.37, 0.755, 0.84))[1::2]
    centers = [top + (s + e) / 2 / h * (bottom - top) for s, e in merged]
    rows = {k: at((0, y, 0, y))[1] for k, y in FRONT_NAME_ROWS.items()}
    def cost(off):
        return sum(min(abs(c - (y + off)) for c in centers) for y in rows.values())
    off = min((o / 1000 for o in range(-60, 61, 3)), key=cost)
    out = {}
    for k, y in rows.items():
        idx = min(range(len(centers)), key=lambda n: abs(centers[n] - (y + off)))
        if abs(centers[idx] - (y + off)) <= 0.03:
            s, e = merged[idx]
            p = int((e - s) * 0.35)
            out[k] = reg[max(0, s - p):min(h, e + p)]
    return out


def _vote_line(line: np.ndarray) -> tuple[str | None, float]:
    from collections import Counter
    votes: Counter[str] = Counter()
    total = 0
    for v in engine._variants(line, (1.0, 1.4)):
        total += 1
        val = _clean_name(engine.ocr(v, engine.AR, 7))
        if len(val.replace(" ", "")) >= 3:
            votes[val] += 1
    if not votes:
        return None, 0.0
    val, n = votes.most_common(1)[0]
    return val, round(n / total, 2)


def read_front(img: np.ndarray) -> dict:
    """القراءة الجديدة: تحديد البطاقة بالرقم الوطني ثم توزيع الأسطر بالعناوين (front_reader)."""
    from .front_reader import fix_national_number, read_front_v2

    res = read_front_v2(img)
    f = res["fields"]
    nid = f["national_id_number"]
    fixed, changed = fix_national_number(nid.value, f["gender"].value)
    if changed:
        f["national_id_number"] = Field(fixed, 0.6)
        res.setdefault("notes", []).append("صُححت الخانة الأولى من الرقم الوطني تلقائيًا؛ تأكد منها.")
    return res


def _locate_back_by_mrz(img: np.ndarray):
    """إن لم تُكتشف حواف البطاقة: نجد الشريط السفلي (أسطر فيها «<<») ونقص البطاقة حوله."""
    g = _gray(img)
    k = min(1.0, 1600 / max(g.shape[:2]))
    small = cv2.resize(g, None, fx=k, fy=k, interpolation=cv2.INTER_AREA) if k < 1 else g
    for rot in (None, cv2.ROTATE_180):
        s = small if rot is None else cv2.rotate(small, rot)
        d = pytesseract.image_to_data(s, lang="eng", config=f"--psm 11 -c tessedit_char_whitelist={_MRZ_WL}",
                                      output_type=pytesseract.Output.DICT)
        boxes = [(d["left"][i], d["top"][i], d["width"][i], d["height"][i]) for i, t in enumerate(d["text"])
                 if t.count("<") >= 3 and len(t) >= 8]
        if not boxes:
            continue
        x1 = min(b[0] for b in boxes); x2 = max(b[0] + b[2] for b in boxes)
        y2 = max(b[1] + b[3] for b in boxes)
        cw = (x2 - x1) / 0.92
        ch = cw / 1.586
        cx = (x1 + x2) / 2
        full = img if rot is None else cv2.rotate(img, rot)
        H, W = full.shape[:2]
        X1, X2 = int(max(0, (cx - cw * 0.53) / k)), int(min(W, (cx + cw * 0.53) / k))
        Y1, Y2 = int(max(0, (y2 + 0.02 * ch - ch * 1.03) / k)), int(min(H, (y2 + 0.04 * ch) / k))
        card = full[Y1:Y2, X1:X2]
        if card.size and card.shape[1] > 200:
            return cv2.resize(card, (1712, 1080), interpolation=cv2.INTER_CUBIC)
    return None


def read_back(img: np.ndarray) -> dict:
    _, found = warp_card(img)
    if not found:
        located = _locate_back_by_mrz(img)
        if located is not None:
            img = located
    g, found2, at = _prepare(img, BACK_ANCHOR, back=True)
    found = found or found2
    out: dict[str, Field] = {}
    region = engine.crop(g, at(BACK["mrz"]))
    cands = [engine.ocr(v, engine.EN, 6, _MRZ_WL) for v in engine._variants(region, (0.4, 0.6, 0.8))]
    mrz = parse_mrz_candidates(cands)
    if not mrz.valid:  # ربما الارتكاز فشل والبطاقة مقلوبة: نجرب الشريط في الاتجاه الآخر
        region = engine.crop(cv2.rotate(g, cv2.ROTATE_180), BACK["mrz"])
        alt = parse_mrz_candidates([engine.ocr(v, engine.EN, 6, _MRZ_WL)
                                    for v in engine._variants(region, (0.4, 0.6, 0.8))])
        if sum(alt.checks.values()) > sum(mrz.checks.values()):
            mrz = alt
    for key in ("issue_date", "expiry_date", "date_of_birth"):
        v, c = engine.read_field(g, at(BACK[key]), engine.EN, lambda t: (d := parse_date(t)) and d.isoformat() or "",
                                 whitelist=_DATE_WL)
        out[key] = Field(parse_date(v) if v else None, c)
    v, c = engine.read_field(g, at(BACK["place_of_birth"]), engine.AR,
                             lambda t: snap_place(clean_arabic(t, allow_hyphen=True)))
    out["place_of_birth"] = Field(v, c)
    v, c = engine.read_field(g, at(BACK["issuer"]), engine.AR,
                             lambda t: snap(clean_arabic(t), ISSUERS, 0.55) or "")
    out["issuer"] = Field(v, c)
    v, c = engine.read_field(g, at(BACK["family_number"]), engine.EN, _family_number, whitelist=_ALNUM_WL)
    out["family_number"] = Field(v, c)
    return {"card_detected": found, "fields": out, "mrz": mrz}


def merge(front: dict | None, back: dict | None) -> dict:
    """يدمج الوجه والظهر ويطبق التحقق المتقاطع مع MRZ."""
    f = dict(front["fields"]) if front else {}
    f.update(back["fields"] if back else {})
    warnings: list[str] = list((front or {}).get("notes", []))
    mrz = back["mrz"] if back else None

    def prefer_mrz(key, mrz_value, label):
        if mrz_value is None:
            return
        cur = f.get(key)
        if cur is None or cur.value is None:
            f[key] = Field(mrz_value, 0.99, "mrz")
        elif cur.value == mrz_value:
            f[key] = Field(mrz_value, 1.0, "mrz+ocr")
        else:
            warnings.append(f"اختلفت قراءة «{label}» بين النص والشريط السفلي، واعتُمد الشريط (موثوق أكثر).")
            f[key] = Field(mrz_value, 0.97, "mrz")

    if mrz:
        if mrz.checks.get("document_number"):
            prefer_mrz("card_number", mrz.document_number, "رقم البطاقة")
            if mrz.national_id_number and len(mrz.national_id_number) == 12:
                prefer_mrz("national_id_number", mrz.national_id_number, "الرقم الوطني")
        if mrz.checks.get("dates"):
            prefer_mrz("date_of_birth", mrz.date_of_birth, "تاريخ الميلاد")
            prefer_mrz("expiry_date", mrz.expiry_date, "تاريخ النفاذ")
            if mrz.sex:
                prefer_mrz("gender", mrz.sex, "الجنس")
        if mrz.surname_latin:
            f["name_latin"] = Field(f"{mrz.given_names_latin} {mrz.surname_latin}".strip(), 0.8, "mrz")
        if not mrz.valid:
            warnings.append("تعذر التحقق الكامل من الشريط السفلي في ظهر البطاقة؛ راجع الأرقام والتواريخ.")

    keys = ("first_name", "father_name", "grandfather_name", "surname")
    labels = {"first_name": "الاسم", "father_name": "اسم الأب", "grandfather_name": "اسم الجد", "surname": "اللقب"}
    parts = [f.get(k) for k in keys]
    if any(p and p.value for p in parts):
        missing = [labels[k] for k, p in zip(keys, parts) if not (p and p.value)]
        f["full_name"] = Field(" ".join(p.value for p in parts if p and p.value),
                               0.0 if missing else round(min(p.confidence for p in parts), 2))
        if missing:  # لا نُخفي النقص: اسم ثلاثي يبدو صحيحًا وهو ناقص
            warnings.append(f"لم يُقرأ ({'، '.join(missing)}) بوضوح؛ أكمل الاسم الرباعي يدويًا.")
    # تحقق داخلي: الخانات 2–4 من الرقم الوطني = آخر ثلاث خانات من سنة الميلاد
    nid, dob = f.get("national_id_number"), f.get("date_of_birth")
    if nid and nid.value and dob and dob.value and len(str(nid.value)) == 12:
        if str(nid.value)[1:4] != str(dob.value.year)[1:4]:
            warnings.append("الرقم الوطني لا يتطابق مع سنة الميلاد؛ راجع الرقم والتاريخ.")
    exp = f.get("expiry_date")
    if exp and exp.value:
        from datetime import date
        if exp.value < date.today():
            warnings.append("البطاقة منتهية الصلاحية.")
    if front and not front["card_detected"]:
        warnings.append("لم تُكتشف حواف البطاقة في صورة الوجه؛ قد تكون القراءة أضعف.")
    if back and not back["card_detected"]:
        warnings.append("لم تُكتشف حواف البطاقة في صورة الظهر؛ قد تكون القراءة أضعف.")
    return {
        "document_type": "iraq_national_id",
        "fields": {k: v.as_dict() for k, v in f.items()},
        "mrz_verified": bool(mrz and mrz.valid),
        "warnings": warnings,
    }
