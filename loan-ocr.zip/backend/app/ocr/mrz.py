"""قراءة وتحقق شريط MRZ (صيغة TD1: ثلاثة أسطر × 30 حرفًا) في ظهر البطاقة الوطنية العراقية.

الفكرة: نقرأ الشريط بعدة طرق، ونقبل فقط القراءة التي تنجح في «أرقام التحقق»
(check digits) المطبوعة داخل الشريط نفسه. هذا يجعل الحقول المستخرجة منه موثوقة جدًا.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import date

_WEIGHTS = (7, 3, 1)
# أخطاء OCR الشائعة: حروف تُقرأ بدل أرقام والعكس
_TO_DIGIT = str.maketrans({"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "Z": "2",
                           "S": "5", "B": "8", "G": "6", "T": "7", "A": "4"})


def check_digit(value: str) -> str:
    total = 0
    for i, ch in enumerate(value):
        if ch.isdigit():
            v = int(ch)
        elif ch.isalpha():
            v = ord(ch) - 55
        else:  # '<'
            v = 0
        total += v * _WEIGHTS[i % 3]
    return str(total % 10)


def _yymmdd(s: str, future: bool) -> date | None:
    try:
        yy, mm, dd = int(s[:2]), int(s[2:4]), int(s[4:6])
        today = date.today()
        year = 2000 + yy
        if not future and year > today.year:
            year -= 100
        return date(year, mm, dd)
    except ValueError:
        return None


@dataclass
class MRZResult:
    document_number: str | None = None
    national_id_number: str | None = None
    date_of_birth: date | None = None
    sex: str | None = None
    expiry_date: date | None = None
    nationality: str | None = None
    surname_latin: str | None = None
    given_names_latin: str | None = None
    checks: dict = field(default_factory=dict)

    @property
    def valid(self) -> bool:
        return bool(self.checks) and all(self.checks.values())


def _parse_line1(text: str):
    """IDIRQ + رقم البطاقة (9) + رقم تحقق + بيانات اختيارية (الرقم الوطني)."""
    for m in re.finditer(r"IRQ([A-Z0-9<]{9})([0-9A-Z])([A-Z0-9<]{0,15})", text):
        num = m.group(1)
        num = num[0] + num[1:].translate(_TO_DIGIT)  # الحرف الأول حرف، الباقي أرقام
        chk = m.group(2).translate(_TO_DIGIT)
        if check_digit(num) == chk:
            optional = m.group(3).split("<")[0].translate(_TO_DIGIT)
            return num.replace("<", ""), optional
    return None


def _parse_line2(text: str):
    t = text.replace(" ", "")
    # نحول أول 15 خانة لأرقام (عدا خانة الجنس)
    for m in re.finditer(r"([0-9A-Z]{6})([0-9A-Z])([MF<])([0-9A-Z]{6})([0-9A-Z])", t):
        dob, c1, sex, exp, c2 = (g.translate(_TO_DIGIT) if i != 2 else g for i, g in enumerate(m.groups()))
        if check_digit(dob) == c1 and check_digit(exp) == c2:
            rest = t[m.end():]
            nat = "IRQ" if re.match(r"[I1]?R[QO0]", rest) else rest[:3]
            return dob, sex, exp, nat
    return None


def _parse_name(text: str):
    m = re.search(r"([A-Z]+(?:<[A-Z]+)*)<<([A-Z]+(?:<[A-Z]+)*)", text)
    if not m:
        return None
    return m.group(1).replace("<", " "), m.group(2).replace("<", " ")


def parse_mrz_candidates(candidates: list[str]) -> MRZResult:
    """يأخذ عدة قراءات OCR للشريط ويجمع منها أفضل نتيجة محققة."""
    res = MRZResult()
    names = Counter()
    for raw in candidates:
        text = raw.upper().replace(" ", "")
        lines = [ln for ln in text.splitlines() if ln]
        joined = "\n".join(lines)
        if res.document_number is None and (l1 := _parse_line1(joined.replace("\n", ""))):
            res.document_number, res.national_id_number = l1
        if res.date_of_birth is None and (l2 := _parse_line2(joined.replace("\n", " "))):
            dob, sex, exp, nat = l2
            res.date_of_birth = _yymmdd(dob, future=False)
            res.expiry_date = _yymmdd(exp, future=True)
            res.sex = {"M": "male", "F": "female"}.get(sex)
            res.nationality = nat
        for ln in lines[2:] or lines[-1:]:
            if n := _parse_name(ln):
                names[n] += 1
    res.checks = {
        "document_number": res.document_number is not None,
        "dates": res.date_of_birth is not None and res.expiry_date is not None,
    }
    if names:
        (res.surname_latin, res.given_names_latin), _ = names.most_common(1)[0]
    return res
