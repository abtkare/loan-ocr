"""إيجاد «نقطة ارتكاز» ثابتة في البطاقة لتصحيح أي إزاحة بسيطة بعد تعديل المنظور.

الوجه: نبحث عن الرقم الوطني (12 رقمًا). الظهر: نبحث عن تاريخ الميلاد أو أول سطر في الشريط.
نقارن مكانه الفعلي بمكانه المتوقع، ونزيح بقية مناطق الحقول بالفرق نفسه.
"""
from __future__ import annotations

import re

import numpy as np
import pytesseract

from .engine import crop


def find_text_hits(gray: np.ndarray, search_box, pattern: str, whitelist: str) -> list[tuple[float, float]]:
    """يرجع مراكز (cx, cy) كنسب من البطاقة لكل كلمة تطابق النمط."""
    x1, y1, x2, y2 = search_box
    region = crop(gray, search_box)
    h, w = gray.shape[:2]
    for psm in (6, 11):
        data = pytesseract.image_to_data(
            region, lang="eng", config=f"--psm {psm} -c tessedit_char_whitelist={whitelist}",
            output_type=pytesseract.Output.DICT)
        hits = []
        for i, text in enumerate(data["text"]):
            if re.fullmatch(pattern, text.strip()):
                cx = x1 + (data["left"][i] + data["width"][i] / 2) / w
                cy = y1 + (data["top"][i] + data["height"][i] / 2) / h
                hits.append((cy, cx))
        if hits:
            return [(cx, cy) for cy, cx in hits]
    return []


def best_offset(hits, expected, limit: float = 0.08):
    """يطابق كل موضع مكتشف مع أقرب موضع متوقع، ويختار أصغر إزاحة معقولة."""
    pairs = [(hx - ex, hy - ey) for hx, hy in hits for ex, ey in expected]
    pairs = [p for p in pairs if abs(p[0]) < limit and abs(p[1]) < limit]
    return min(pairs, key=lambda p: abs(p[0]) + abs(p[1])) if pairs else None


def shift_box(box, dx: float, dy: float):
    x1, y1, x2, y2 = box
    return (x1 + dx, y1 + dy, x2 + dx, y2 + dy)
