"""قراءة وجه البطاقة الوطنية بالعناوين لا بالمواقع الثابتة.

الخطوات:
1. نحدد البطاقة في الصورة: بالحواف إن أمكن، وإلا بالرقم الوطني نفسه (12 رقمًا كبيرًا)
   فنحسب مكان البطاقة وحجمها منه. هذا يعمل حتى لو كانت البطاقة في اليد وعلى خلفية فاتحة.
2. نقرأ البطاقة كلها قراءة واحدة بالعربية (نموذج Tesseract الأدق «best»)، فيخرج كل سطر
   بصيغة «العنوان : القيمة».
3. نوزع الأسطر على الحقول بحسب العنوان (الاسم، الأب، الجد، اللقب، الأم، الجد، الجنس)
   مع احترام ترتيبها في البطاقة؛ فلا يمكن أن يُكتب اسم الجد مكان الاسم.
4. الأرقام تُقرأ بقراءات إنجليزية قصيرة مع التصويت.
النتيجة: 6–10 قراءات بدل ~80، أي ثوانٍ معدودة بدل دقائق.
"""
from __future__ import annotations

import re
from collections import Counter
from functools import lru_cache

import cv2
import numpy as np
import pytesseract

from ..card_detect import warp_card
from .iraq_data import COMMON_NAMES, fix_name
from .text_utils import clean_arabic, digits_only

CARD_RATIO = 1.586
WORK_W = 1500  # عرض البطاقة الذي نقرأ عليه
# مكان الرقم الوطني داخل البطاقة (نسب): يسار الرقم، عرضه، ومركزه العمودي
NUM_LEFT, NUM_W, NUM_CY = 0.372, 0.267, 0.315


@lru_cache(maxsize=1)
def ar_lang() -> str:
    """نستخدم نموذج العربية الأدق إن كان مثبتًا (ara_best)، وإلا الافتراضي."""
    try:
        return "ara_best" if "ara_best" in pytesseract.get_languages(config="") else "ara"
    except Exception:
        return "ara"


def _gray(img):
    return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _number_boxes(gray: np.ndarray):
    """يبحث عن الرقم الوطني في الصورة كلها ويرجع مربعاته (x, y, w, h, النص)."""
    out = []
    data = pytesseract.image_to_data(gray, lang="eng", config="--psm 11 -c tessedit_char_whitelist=0123456789",
                                     output_type=pytesseract.Output.DICT)
    for i, t in enumerate(data["text"]):
        t = t.strip()
        if 11 <= len(t) <= 13 and t.isdigit():
            out.append((data["left"][i], data["top"][i], data["width"][i], data["height"][i], t))
    return out


def _crop_from_number(img: np.ndarray, box) -> np.ndarray:
    x, y, w, h, _ = box
    cw = w / NUM_W
    ch = cw / CARD_RATIO
    x0 = x - NUM_LEFT * cw
    y0 = y + h / 2 - NUM_CY * ch
    m = 0.03 * cw  # هامش صغير احتياطًا لخطأ التقدير
    H, W = img.shape[:2]
    x1, y1 = int(max(0, x0 - m)), int(max(0, y0 - m))
    x2, y2 = int(min(W, x0 + cw + m)), int(min(H, y0 + ch + m))
    return img[y1:y2, x1:x2]


def _scale_to(img: np.ndarray, width: int) -> np.ndarray:
    s = width / img.shape[1]
    return cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC if s > 1 else cv2.INTER_AREA)


def locate_card(img: np.ndarray):
    """يرجع (صورة البطاقة بعرض ثابت ورمادية، طريقة الإيجاد: edges | number | none)."""
    warped, found = warp_card(img)
    if found:
        g = _gray(warped)
        small = _scale_to(g, 1000)
        for rot in (None, cv2.ROTATE_180):
            s = small if rot is None else cv2.rotate(small, rot)
            if _number_boxes(s):
                return _scale_to(g if rot is None else cv2.rotate(g, rot), WORK_W), "edges"
    g = _gray(img)
    M = max(g.shape[:2])
    k1, k2 = min(1.0, 1600 / M), min(2.0, 3900 / M)
    # نبدأ بالأرخص؛ ثم الدقة الأعلى (بطاقة بعيدة)؛ ثم تعديل الميلان (البطاقة مائلة في اليد)
    est = estimate_skew(g)
    attempts = [(0, k1, False), (0, k1, True), (0, k2, False), (0, k2, True)]
    for a in (est, -4, 4, -8, 8, -12, 12):
        if abs(a) >= 1.5 and all(abs(a - x[0]) > 1.5 for x in attempts):
            attempts.append((a, k1, False))
    for ang, k, flip in attempts:
        gg = _rotate(g, ang) if ang else g
        if flip:
            gg = cv2.rotate(gg, cv2.ROTATE_180)
        hit = _locate_by_number(gg, k)
        if hit is not None:
            # الميلان يُقاس بدقة على البطاقة نفسها (أسطرها نظيفة)، فنعدّله ونعيد القص
            sk = estimate_skew(hit)
            if abs(sk) > 0.8:
                hit2 = _locate_by_number(_rotate(gg, sk), k)
                if hit2 is not None:
                    hit = hit2
            return _scale_to(hit, WORK_W), "number"
    return _scale_to(g, WORK_W), "none"


def estimate_skew(g: np.ndarray) -> float:
    """ميلان أسطر النص بالدرجات (تقدير سريع من كتل الأسطر)."""
    k = 900 / max(g.shape[:2])
    s = cv2.resize(g, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    bh = cv2.morphologyEx(s, cv2.MORPH_BLACKHAT, cv2.getStructuringElement(cv2.MORPH_RECT, (15, 7)))
    _, b = cv2.threshold(bh, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    b = cv2.morphologyEx(b, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (17, 3)))
    cnts, _ = cv2.findContours(b, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    angles, weights = [], []
    for c in cnts:
        (cx, cy), (w, h), a = cv2.minAreaRect(c)
        if w < h:
            w, h, a = h, w, a - 90
        if w > 40 and w > 4 * h:
            a = (a + 90) % 180 - 90
            if abs(a) < 25:
                angles.append(a); weights.append(w)
    if len(angles) < 3:
        return 0.0
    order = np.argsort(angles)
    cum = np.cumsum(np.array(weights)[order])
    return float(np.array(angles)[order][np.searchsorted(cum, cum[-1] / 2)])  # الوسيط الموزون


def _rotate(img: np.ndarray, deg: float) -> np.ndarray:
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), deg, 1)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def _locate_by_number(g: np.ndarray, k: float):
    small = cv2.resize(g, None, fx=k, fy=k, interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_CUBIC)
    boxes = _number_boxes(small)
    if not boxes:
        return None
    best = max(boxes, key=lambda b: b[2] * b[3])
    box = tuple(int(v / k) for v in best[:4]) + (best[4],)
    card = _crop_from_number(g, box)
    return card if card.size and card.shape[1] > 200 else None


# --- توزيع الأسطر على الحقول ---------------------------------------------------
ORDER = ["first_name", "father_name", "grandfather_name", "surname", "mother_name",
         "mother_grandfather_name", "gender", "blood_type"]
# كلمات دالة (بعد التطبيع) لكل عنوان؛ تشمل الكردية وبعض أخطاء القراءة الشائعة
LABELS = {
    "first_name": ("الاسم", "الاسسم", "اسم", "ناو", "نار"),
    "father_name": ("الاب", "باوك", "بارك", "بنرك"),
    "grandfather_name": ("الجد", "بابير", "بير", "بيير", "جد"),
    "surname": ("اللقب", "لقب", "نازناو", "نازدم"),
    "mother_name": ("الام", "دايك", "ديقك", "الا"),
    "mother_grandfather_name": ("الجد", "بابير", "بير", "بيير", "جد"),
    "gender": ("الجنس", "جنس", "رهگهز", "رهكهز"),
    "blood_type": ("فصيلة", "فصيله", "فصبيلة", "الدم", "خوين"),
}
_NORM = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي"})


def _norm(s: str) -> str:
    return clean_arabic(s).translate(_NORM)


def _label_score(label: str, field: str) -> float:
    words = _norm(label).split()
    best = 0.0
    for w in words:
        for k in LABELS[field]:
            k = k.translate(_NORM)
            if w == k:
                best = max(best, 1.0)
            elif len(k) >= 3 and (k in w or w in k) and len(w) >= 2:
                best = max(best, 0.7)
    return best


_SEP = re.compile(r"\s[:;؛>؟?*|!،]\s?|\s?[:;؛]\s")


def _split_line(line: str):
    """«العنوان : القيمة» ← (العنوان، القيمة).
    النقطتان قد تُقرأ رمزًا آخر (* أو ؛ أو ؟)، فنأخذ آخر فاصل يليه نص عربي."""
    best = None
    for m in _SEP.finditer(line):
        if len(clean_arabic(line[m.end():]).replace(" ", "")) >= 2:
            best = m
    if best is None:
        m = _SEP.search(line)
        if not m:
            return None
        best = m
    return line[:best.start()], line[best.end():]


def _align(lines):
    """يطابق الأسطر مع الحقول بالترتيب (برمجة ديناميكية): العنوان يرجّح، والترتيب يحسم."""
    n, m = len(lines), len(ORDER)
    NEG = -1e9
    dp = [[NEG] * (m + 1) for _ in range(n + 1)]
    bt = [[None] * (m + 1) for _ in range(n + 1)]
    for j in range(m + 1):
        dp[0][j] = 0
    for i in range(1, n + 1):
        dp[i][0] = 0
    for i in range(1, n + 1):
        lab = lines[i - 1][0]
        for j in range(1, m + 1):
            opts = [(dp[i - 1][j], "skip_line"), (dp[i][j - 1], "skip_field")]
            sc = _label_score(lab, ORDER[j - 1])
            opts.append((dp[i - 1][j - 1] + 0.3 + sc * 2, "match"))
            dp[i][j], bt[i][j] = max(opts, key=lambda o: o[0])
    out, i, j = {}, n, m
    while i > 0 and j > 0:
        mv = bt[i][j]
        if mv == "match":
            out[ORDER[j - 1]] = lines[i - 1][1]
            i, j = i - 1, j - 1
        elif mv == "skip_line":
            i -= 1
        else:
            j -= 1
    return out


def _clean_value(v: str) -> str:
    toks = [t for t in clean_arabic(v).split() if len(t) >= 2]
    # كلمة مقطوعة بمسافة خاطئة («عو اطف» = عواطف)
    if len(toks) >= 2 and toks[0] != "عبد" and (len(toks[0]) <= 2 or len(toks[1]) <= 2):
        toks = [toks[0] + toks[1]] + toks[2:]
    # «عيد/عبر» قبل اسم = «عبد» (أشهر خطأ في الأسماء المركبة)
    fixed = []
    for i, t in enumerate(toks):
        if i + 1 < len(toks) and len(t) == 3 and t != "عبد" and sum(a == b for a, b in zip(t, "عبد")) >= 2:
            t = "عبد"
        fixed.append(t)
    # الاسم في البطاقة كلمة أو كلمتان (عبد + اسم)؛ ما زاد فهو ضجيج في طرف السطر
    if fixed and fixed[0] == "عبد":
        fixed = fixed[:2]
    else:
        fixed = fixed[:1] if fixed else []
    out = fix_name(" ".join(fixed))
    # قراءة ناقصة (حرفان) أسوأ من حقل فارغ: نتركه ليكتبه المستخدم
    return out if len(out.replace(" ", "")) >= 3 and not out.endswith(" عبد") else ""


def _gender(v: str) -> str:
    t = _norm(v)
    if "انث" in t or "نثي" in t or "مي" == t[:2]:
        return "female"
    if "ذك" in t or "دك" in t or "كر" in t or "نير" in t:
        return "male"
    return ""


def _blood(text: str) -> str:
    t = text.upper().replace("0", "O").replace(" ", "")
    m = re.search(r"(AB|A|B|O)[+-]", t)
    if m:
        return m.group(0)
    m = re.search(r"([+-])(AB|A|B|O)(?![A-Z])", t)  # قد يخرج معكوسًا بسبب اتجاه السطر العربي
    return m.group(2) + m.group(1) if m else ""


def fix_national_number(nid: str | None, gender: str | None) -> tuple[str | None, bool]:
    """الخانة الأولى تدل على الجنس والقرن (1 ذكر/2 أنثى لمواليد 19xx، 3 ذكر/4 أنثى لمواليد 20xx)
    والخانات 2–4 آخر ثلاث خانات من سنة الميلاد. Tesseract يخطئ كثيرًا في «1» الأولى، فنصححها
    حين تتعارض مع سنة الميلاد. يرجع (الرقم، هل صُحح)."""
    if not nid or len(nid) != 12:
        return nid, False
    first, yy = nid[0], nid[1:4]
    if yy[0] == "9":
        allowed = {"male": "1", "female": "2"}
    elif yy[0] == "0":
        allowed = {"male": "3", "female": "4"}
    else:
        return nid, False
    if first in allowed.values():
        return nid, False
    if gender in allowed:
        return allowed[gender] + nid[1:], True
    return nid, False


def _read_names(card: np.ndarray) -> tuple[dict, list[str]]:
    txt = pytesseract.image_to_string(card, lang=ar_lang(), config="--psm 6")
    lines = []
    for raw in txt.splitlines():
        sp = _split_line(raw)
        if sp:
            lines.append(sp)
    return _align(lines), txt.splitlines()


def _vote_digits(card: np.ndarray, box, pattern: str, whitelist="0123456789"):
    """يقرأ المنطقة بعدة مقاسات وحدّة، ثم يصوّت خانةً خانة (لا على الرقم كاملًا):
    خطأ في خانة واحدة بإحدى القراءات لا يُفسد النتيجة. الثقة = متوسط اتفاق الخانات."""
    h, w = card.shape[:2]
    x1, y1, x2, y2 = box
    reg = card[max(0, int(y1 * h)):int(y2 * h), max(0, int(x1 * w)):int(x2 * w)]
    if reg.size == 0:
        return None, 0.0
    cands: list[str] = []
    for sc in (0.8, 1.0, 1.3):
        r = cv2.resize(reg, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA if sc < 1 else cv2.INTER_CUBIC)
        r = cv2.copyMakeBorder(r, 20, 20, 20, 20, cv2.BORDER_REPLICATE)
        sharp = cv2.addWeighted(r, 1.8, cv2.GaussianBlur(r, (0, 0), 3), -0.8, 0)
        for v in (r, sharp):
            t = pytesseract.image_to_string(v, lang="eng", config=f"--psm 7 -c tessedit_char_whitelist={whitelist}")
            cands += re.findall(pattern, t.replace(" ", ""))
    if not cands:
        return None, 0.0
    n = Counter(len(c) for c in cands).most_common(1)[0][0]
    same = [c for c in cands if len(c) == n]
    out, agree = "", []
    for i in range(n):
        ch, k = Counter(c[i] for c in same).most_common(1)[0]
        out += ch
        agree.append(k / 6)
    if not re.fullmatch(pattern, out):
        out = Counter(cands).most_common(1)[0][0]
    return out, round(min(1.0, sum(agree) / len(agree)), 2)


def _card_letter(card: np.ndarray) -> str:
    h, w = card.shape[:2]
    reg = card[int(0.86 * h):int(0.985 * h), int(0.03 * w):int(0.40 * w)]
    reg = cv2.copyMakeBorder(reg, 20, 20, 20, 20, cv2.BORDER_REPLICATE)
    t = pytesseract.image_to_string(reg, lang="eng",
                                    config="--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789(©")
    t = t.strip().replace(" ", "").replace("(", "C").replace("©", "C")
    m = re.match(r"([A-Z])\d{6,}", t)
    return m.group(1) if m else ""


def read_front_v2(img: np.ndarray) -> dict:
    from .national_id import Field  # تجنب الاستيراد الدائري

    card, how = locate_card(img)
    out: dict[str, Field] = {}
    if how == "none":  # لم نجد البطاقة: لا نخمّن (التخمين هو ما ملأ الحقول بأسماء خاطئة سابقًا)
        for key in ORDER + ["national_id_number", "card_number"]:
            out[key] = Field(None, 0.0)
        return {"card_detected": False, "locate": how, "fields": out}
    names, raw_lines = _read_names(card)
    for key in ORDER[:6]:
        v = _clean_value(names.get(key, ""))
        # اسم معروف في القاموس = ثقة عالية؛ غير معروف = يُظلل ليراجعه المستخدم
        known = v and all(w in COMMON_NAMES for w in v.split())
        out[key] = Field(v or None, (0.9 if known else 0.65) if v else 0.0)
    g = _gender(names.get("gender", ""))
    out["gender"] = Field(g or None, 0.8 if g else 0.0)

    nid, c = _vote_digits(card, (0.30, 0.28, 0.70, 0.42), r"\d{12}")
    out["national_id_number"] = Field(nid, c)
    # رقم البطاقة: حرف + 8 أرقام (مثل C38636752). الحرف الأول كثيرًا ما يُقرأ رمزًا، فنقرأ الأرقام
    # بالتصويت ثم الحرف وحده؛ والشريط السفلي في الظهر يصحح الرقم كاملًا إن صُوّر
    cn, c2 = _vote_digits(card, (0.03, 0.86, 0.40, 0.985), r"\d{8}")
    letter = _card_letter(card) if cn else ""
    out["card_number"] = Field(letter + cn if cn and letter else cn, c2 if letter else min(c2, 0.5))
    bt = _blood(names.get("blood_type", "") + " " + " ".join(raw_lines[-3:]))
    out["blood_type"] = Field(bt or None, 0.6 if bt else 0.0)
    return {"card_detected": how != "none", "locate": how, "fields": out}
