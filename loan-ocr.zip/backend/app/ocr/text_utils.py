"""تنظيف نصوص OCR العربية والتواريخ والأرقام."""
import re
from datetime import date

_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_AR_LETTERS = r"ء-غف-ي"


def clean_arabic(text: str, allow_hyphen: bool = False) -> str:
    """يبقي الحروف العربية فقط، ويحذف الرموز والحروف المنفردة الناتجة عن الضجيج."""
    text = text.replace("ـ", "")  # التطويل
    text = re.sub(r"[ً-ْ]", "", text)  # التشكيل
    keep = _AR_LETTERS + (r"\-" if allow_hyphen else "")
    text = re.sub(rf"[^{keep}\s]", " ", text)
    tokens = [t for t in text.split() if len(t) > 1 or t == "-"]
    out = " ".join(tokens)
    return re.sub(r"\s*-\s*", "-", out).strip("- ")


def digits_only(text: str) -> str:
    return re.sub(r"\D", "", text.translate(_AR_DIGITS))


def parse_date(text: str) -> date | None:
    t = text.translate(_AR_DIGITS)
    m = re.search(r"(\d{4})\D?(\d{1,2})\D?(\d{1,2})", t)
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None
