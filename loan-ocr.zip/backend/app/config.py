"""الإعدادات من متغيرات البيئة (ملف .env عند التشغيل عبر Docker)."""
import os

MAX_UPLOAD_MB = float(os.getenv("MAX_UPLOAD_MB", "8"))
# عدد عمليات القراءة المتزامنة. على سيرفر بنواة واحدة: 1
OCR_WORKERS = int(os.getenv("OCR_WORKERS", "1"))
# مفتاح اختياري يطلبه التطبيق من الواجهة/تطبيق الهاتف في الترويسة X-API-Key
API_KEY = os.getenv("API_KEY", "")
# حد الطلبات لكل عنوان IP في الدقيقة (حماية بسيطة من الإغراق)
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "20"))
# النطاقات المسموح لها باستدعاء الواجهة البرمجية من متصفح آخر (مفصولة بفواصل)
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
FRONTEND_DIR = os.getenv("FRONTEND_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "frontend"))
