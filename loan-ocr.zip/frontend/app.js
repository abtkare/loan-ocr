/* واجهة تصوير البطاقة وملء النموذج تلقائيًا.
 * بلا مكتبات خارجية: تعمل على أي متصفح هاتف حديث.
 * نفس الواجهة البرمجية (API) ستستخدمها تطبيقات الهاتف لاحقًا.
 */
(() => {
  "use strict";

  const API_URL = "/api/v1/documents/national-id";
  const API_KEY = ""; // ضع المفتاح هنا إن فعّلت API_KEY في الخادم
  const MAX_SIDE = 1800; // نصغّر الصورة قبل الرفع: أسرع وأخف ولا تتأثر الدقة
  const CONFIDENT = 0.75; // أقل من هذه الثقة نطلب من المستخدم المراجعة

  const $ = (s, el = document) => el.querySelector(s);
  const images = { front: null, back: null }; // Blob لكل وجه — تبقى في الذاكرة فقط
  let currentSide = null;
  let stream = null;

  const camDialog = $("#camera");
  const video = $("#video");
  const readBtn = $("#readBtn");
  const statusEl = $("#status");
  const form = $("#loanForm");

  // ---------- التقاط الصور ----------
  document.querySelectorAll(".shot").forEach((btn) =>
    btn.addEventListener("click", () => openCamera(btn.dataset.side)));

  async function openCamera(side) {
    currentSide = side;
    $("#camHint").textContent = side === "front"
      ? "ضع وجه البطاقة داخل الإطار" : "ضع ظهر البطاقة داخل الإطار (مع الشريط السفلي)";
    if (!navigator.mediaDevices?.getUserMedia) {
      $("#fileInput").click(); // متصفح قديم أو صفحة بدون HTTPS: نفتح الكاميرا/المعرض مباشرة
      return;
    }
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      video.srcObject = stream;
      camDialog.showModal();
    } catch (e) {
      setStatus("تعذر فتح الكاميرا. اسمح للموقع باستخدامها، أو اختر صورة من المعرض.", "error");
      $("#fileInput").click();
    }
  }

  function closeCamera() {
    stream?.getTracks().forEach((t) => t.stop());
    stream = null;
    video.srcObject = null;
    if (camDialog.open) camDialog.close();
  }

  $("#camClose").addEventListener("click", closeCamera);
  camDialog.addEventListener("cancel", closeCamera);

  $("#camShoot").addEventListener("click", async () => {
    if (!video.videoWidth) return;
    const canvas = scaleToCanvas(video, video.videoWidth, video.videoHeight);
    const blob = await toJpeg(canvas);
    closeCamera();
    accept(blob, canvas);
  });

  $("#fileInput").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    closeCamera();
    try {
      const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
      const canvas = scaleToCanvas(bitmap, bitmap.width, bitmap.height);
      bitmap.close();
      accept(await toJpeg(canvas), canvas);
    } catch {
      setStatus("الملف المختار ليس صورة مدعومة.", "error");
    }
  });

  function scaleToCanvas(source, w, h) {
    const s = Math.min(1, MAX_SIDE / Math.max(w, h));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(w * s);
    canvas.height = Math.round(h * s);
    canvas.getContext("2d").drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  const toJpeg = (canvas) => new Promise((r) => canvas.toBlob(r, "image/jpeg", 0.92));

  // فحص سريع للجودة قبل الإرسال: الإضاءة فقط (الباقي يتحقق منه الخادم)
  function brightness(canvas) {
    const small = scaleToCanvas(canvas, canvas.width, canvas.height);
    const c = document.createElement("canvas");
    c.width = 64; c.height = 64;
    const ctx = c.getContext("2d");
    ctx.drawImage(small, 0, 0, 64, 64);
    const d = ctx.getImageData(0, 0, 64, 64).data;
    let sum = 0;
    for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    return sum / (d.length / 4);
  }

  function accept(blob, canvas) {
    const side = currentSide;
    images[side] = blob;
    const btn = $(`.shot[data-side="${side}"]`);
    const thumb = $(".thumb", btn);
    const old = $("img", thumb);
    if (old) URL.revokeObjectURL(old.src);
    thumb.innerHTML = "";
    const img = new Image();
    img.alt = "";
    img.src = URL.createObjectURL(blob);
    thumb.appendChild(img);
    btn.classList.add("done");
    const b = brightness(canvas);
    $(".state", btn).textContent = b < 60 ? "الصورة مظلمة — يُفضّل إعادتها" : "تم ✓ (اضغط للإعادة)";
    updateReadBtn();
  }

  // ---------- الإرسال للقراءة ----------
  const consent = $("#consent");
  consent.addEventListener("change", updateReadBtn);
  function updateReadBtn() {
    readBtn.disabled = !(consent.checked && (images.front || images.back));
  }

  readBtn.addEventListener("click", async () => {
    const body = new FormData();
    if (images.front) body.append("front", images.front, "front.jpg");
    if (images.back) body.append("back", images.back, "back.jpg");
    readBtn.disabled = true;
    setStatus("جارٍ قراءة البطاقة… قد يستغرق ذلك من 10 إلى 30 ثانية.", "loading");
    try {
      const headers = API_KEY ? { "X-API-Key": API_KEY } : {};
      const res = await fetch(API_URL, { method: "POST", body, headers });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error?.message || "حدث خطأ في الخادم.");
      fillForm(data);
      clearImages(); // لم نعد نحتاج الصور: نحذفها من ذاكرة المتصفح
      const n = Object.values(data.fields).filter((f) => f.value).length;
      setStatus(`تمت القراءة: ${n} حقلًا. راجع البيانات في الأسفل.`, "success");
      form.scrollIntoView({ behavior: "smooth" });
    } catch (e) {
      setStatus(e.message === "Failed to fetch" ? "تعذر الاتصال بالخادم. تحقق من الإنترنت." : e.message, "error");
    } finally {
      updateReadBtn();
    }
  });

  function clearImages() {
    for (const side of ["front", "back"]) {
      images[side] = null;
      const btn = $(`.shot[data-side="${side}"]`);
      const img = $(".thumb img", btn);
      if (img) { URL.revokeObjectURL(img.src); img.remove(); }
      $(".thumb", btn).innerHTML = '<svg viewBox="0 0 86 54" aria-hidden="true"><rect x="1" y="1" width="84" height="52" rx="5"/></svg>';
      $(".state", btn).textContent = "قُرئت ✓ (اضغط لإعادة التصوير)";
    }
  }

  function fillForm(data) {
    const warnBox = $("#warnings");
    warnBox.innerHTML = "";
    (data.warnings || []).forEach((w) => {
      const div = document.createElement("div");
      div.className = "alert";
      div.textContent = w;
      warnBox.appendChild(div);
    });

    for (const [name, f] of Object.entries(data.fields || {})) {
      const input = form.elements[name];
      if (!input || f.value == null || f.value === "") continue;
      const label = input.closest("label");
      // لا نستبدل ما كتبه المستخدم بيده
      if (input.dataset.userEdited === "1" && input.value) continue;
      input.value = f.value;
      const verified = f.source.includes("mrz") && f.confidence >= 0.95;
      const ok = verified || f.confidence >= CONFIDENT;
      label.classList.remove("filled-ok", "filled-warn");
      label.classList.add(ok ? "filled-ok" : "filled-warn");
      $(".badge", label)?.remove();
      const badge = document.createElement("span");
      badge.className = `badge ${verified ? "ok" : ok ? "ok" : "warn"}`;
      badge.textContent = verified ? "مُتحقق" : ok ? "مقروء" : "راجِع";
      label.appendChild(badge);
    }
  }

  form.addEventListener("input", (e) => {
    const input = e.target;
    input.dataset.userEdited = "1";
    input.classList.remove("invalid");
    const label = input.closest("label");
    if (label?.classList.contains("filled-warn")) {
      label.classList.replace("filled-warn", "filled-ok");
      const badge = $(".badge", label);
      if (badge) { badge.className = "badge ok"; badge.textContent = "عُدّل"; }
    }
  });

  // ---------- إرسال الطلب ----------
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let firstBad = null;
    for (const el of form.elements) {
      if (!el.name) continue;
      const bad = !el.checkValidity();
      el.classList.toggle("invalid", bad);
      if (bad && !firstBad) firstBad = el;
    }
    if (firstBad) {
      firstBad.focus();
      firstBad.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const payload = Object.fromEntries(new FormData(form));
    // TODO: أرسل payload إلى خادم طلبات القروض لديك بدل عرضه
    $("#resultJson").textContent = JSON.stringify(payload, null, 2);
    $("#result").showModal();
  });

  function setStatus(msg, kind = "") {
    statusEl.textContent = msg;
    statusEl.className = `status ${kind}`;
  }
})();
