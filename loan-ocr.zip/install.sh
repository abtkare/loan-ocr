#!/usr/bin/env bash
# تثبيت وتشغيل نظام قراءة البطاقة الوطنية بأمر واحد على Ubuntu.
# الاستخدام:  bash install.sh            (يستخدم اسم السيرفر كنطاق)
#            bash install.sh my.domain.com
set -euo pipefail
cd "$(dirname "$0")"

say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "شغّل الأمر بصلاحية root (أضف sudo قبله)."

if ! command -v docker >/dev/null 2>&1; then
  say "تثبيت Docker (مرة واحدة فقط)…"
  curl -fsSL https://get.docker.com | sh
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose غير متوفر. حدّث Docker ثم أعد المحاولة."

DOMAIN="${1:-}"
if [ -f .env ]; then
  [ -n "$DOMAIN" ] && sed -i "s|^DOMAIN=.*|DOMAIN=$DOMAIN|" .env
else
  cp .env.example .env
  [ -n "$DOMAIN" ] || DOMAIN="$(hostname -f)"
  sed -i "s|^DOMAIN=.*|DOMAIN=$DOMAIN|" .env
fi
DOMAIN="$(grep '^DOMAIN=' .env | cut -d= -f2)"
say "النطاق: $DOMAIN"

# التحقق من أن المنافذ 80 و443 غير مستخدمة من برنامج آخر (مثل nginx أو apache)
for port in 80 443; do
  if ss -ltnp 2>/dev/null | grep -q ":$port " && ! ss -ltnp | grep ":$port " | grep -q docker; then
    die "المنفذ $port مستخدم من برنامج آخر على السيرفر. راجع قسم «موقع آخر على نفس السيرفر» في دليل التشغيل."
  fi
done

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  say "فتح المنفذين 80 و443 في الجدار الناري…"
  ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
fi

say "بناء وتشغيل الخدمة (قد يأخذ 3–5 دقائق في المرة الأولى)…"
docker compose up -d --build

say "انتظار جاهزية الخدمة…"
for _ in $(seq 1 60); do
  if docker compose exec -T app python -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8000/api/health')" >/dev/null 2>&1; then
    say "تم التشغيل ✓  افتح من هاتفك:  https://$DOMAIN"
    echo "   (قد تتأخر شهادة HTTPS دقيقة واحدة في أول مرة)"
    exit 0
  fi
  sleep 3
done
die "الخدمة لم تعمل. أرسل ناتج هذا الأمر للدعم:  docker compose logs --tail=80"
